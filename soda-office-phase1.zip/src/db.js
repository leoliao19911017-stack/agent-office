// Soda Office 数据库层。
// 驱动用 node-sqlite3-wasm（纯 WASM，本机无 C++ 工具链也能装），
// API 接近 better-sqlite3：同步、.exec / .run / .get / .all。
//
// 约定：
// - 时间戳一律存 Unix epoch 毫秒（INTEGER），比较大小即比较先后；
// - JSON 字段（capabilities / payload）以字符串落库，读取方自行 parse；
// - 查询函数返回原始行，查无返回 null / 空数组，不编数据。
import { randomUUID } from 'node:crypto';
import pkg from 'node-sqlite3-wasm';

// node-sqlite3-wasm 是 CJS 包，default 导出挂在 pkg.default 上，两种形状都兼容
const { Database } = pkg.default ?? pkg;

/** Agent 工作状态，口径对齐 soda-agent-workspace（其客户端 sync 也只认这四个） */
export const AGENT_STATUSES = ['working', 'idle', 'blocked', 'done'];

/** 实时事件类型，口径对齐 soda-agent-workspace 第六节（start/step/cmd/end/blocked/error/note） */
export const EVENT_TYPES = ['start', 'step', 'cmd', 'end', 'blocked', 'error', 'note'];

/** 任务状态机，对齐 office_adapter 的设计：queued → claimed → running → done/failed/cancelled/blocked */
export const TASK_STATUSES = ['queued', 'claimed', 'running', 'done', 'failed', 'cancelled', 'blocked'];

export const SCHEMA = `
CREATE TABLE IF NOT EXISTS agents (
  id             TEXT PRIMARY KEY,
  name           TEXT NOT NULL,
  type           TEXT NOT NULL DEFAULT 'unknown',
  status         TEXT NOT NULL DEFAULT 'idle',
  last_heartbeat INTEGER,
  capabilities   TEXT NOT NULL DEFAULT '[]',
  created_at     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS tasks (
  id          TEXT PRIMARY KEY,
  title       TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  assignee    TEXT REFERENCES agents(id),
  status      TEXT NOT NULL DEFAULT 'queued',
  claimed_at  INTEGER,
  created_at  INTEGER NOT NULL,
  result_path TEXT
);

CREATE TABLE IF NOT EXISTS events (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id    TEXT REFERENCES tasks(id),
  agent_id   TEXT REFERENCES agents(id),
  type       TEXT NOT NULL,
  payload    TEXT NOT NULL DEFAULT '{}',
  created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_tasks_status     ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_events_task_id   ON events(task_id);
CREATE INDEX IF NOT EXISTS idx_events_agent_id  ON events(agent_id);
`;

/** 打开数据库连接并启用外键约束（SQLite 默认不启用） */
export function openDatabase(path = ':memory:') {
  const db = new Database(path);
  db.exec('PRAGMA foreign_keys = ON');
  return db;
}

/** 打开并建表。幂等（IF NOT EXISTS），重复调用安全。 */
export function initializeDatabase(path = ':memory:') {
  const db = openDatabase(path);
  db.exec(SCHEMA);
  return db;
}

export function closeDatabase(db) {
  if (db) db.close();
}

/**
 * 注册一个 Agent，返回落库后的完整行（capabilities 已序列化为 JSON 字符串）。
 * 入参用 camelCase（lastHeartbeat），落库转 snake_case。
 */
export function insertAgent(db, agent) {
  if (!agent || typeof agent !== 'object') throw new TypeError('agent 必须是对象');
  const { name, type, status, capabilities, lastHeartbeat } = agent;
  if (typeof name !== 'string' || name.trim() === '') {
    throw new TypeError('agent.name 必须是非空字符串');
  }
  if (type !== undefined && typeof type !== 'string') throw new TypeError('agent.type 必须是字符串');
  if (status !== undefined && !AGENT_STATUSES.includes(status)) {
    throw new RangeError(`agent.status 必须是 ${AGENT_STATUSES.join(' / ')} 之一，收到：${status}`);
  }
  if (capabilities !== undefined && !Array.isArray(capabilities)) {
    throw new TypeError('agent.capabilities 必须是数组');
  }
  if (lastHeartbeat !== undefined && typeof lastHeartbeat !== 'number') {
    throw new TypeError('agent.lastHeartbeat 必须是数字（epoch 毫秒）');
  }

  const row = {
    id: typeof agent.id === 'string' && agent.id ? agent.id : randomUUID(),
    name: name.trim(),
    type: type ?? 'unknown',
    status: status ?? 'idle',
    last_heartbeat: lastHeartbeat ?? null,
    capabilities: JSON.stringify(capabilities ?? []),
    created_at: Date.now(),
  };
  db.run(
    'INSERT INTO agents (id, name, type, status, last_heartbeat, capabilities, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [row.id, row.name, row.type, row.status, row.last_heartbeat, row.capabilities, row.created_at],
  );
  return row;
}

/** 按 id 查 Agent，查无返回 null。 */
export function getAgentById(db, id) {
  return db.get('SELECT * FROM agents WHERE id = ?', [id]) ?? null;
}

/** Agent 全量列表，按注册先后排序（created_at 同毫秒时按 rowid 决胜，保证插入序稳定）。 */
export function listAgents(db) {
  return db.all('SELECT * FROM agents ORDER BY created_at, rowid');
}

/** 按名字精确查 Agent（注册查重用），查无返回 null。 */
export function findAgentByName(db, name) {
  return db.get('SELECT * FROM agents WHERE name = ?', [name]) ?? null;
}

/**
 * 更新 Agent 状态，并把 last_heartbeat 刷到当前时刻（口径：状态更新即心跳，不可省）。
 * 返回更新后的完整行；Agent 不存在时不写入、返回 null。
 */
export function updateAgentStatus(db, id, status) {
  if (!AGENT_STATUSES.includes(status)) {
    throw new RangeError(`status 必须是 ${AGENT_STATUSES.join(' / ')} 之一，收到：${status}`);
  }
  db.run('UPDATE agents SET status = ?, last_heartbeat = ? WHERE id = ?', [status, Date.now(), id]);
  return getAgentById(db, id); // UPDATE 命中 0 行时这里自然返回 null，不用看 changes 计数
}

// ---------------------------------------------------------------------------
// 任务（tasks）
// ---------------------------------------------------------------------------

/**
 * 建任务，返回落库后的完整行。
 * title 必须非空字符串；status 默认 queued；assignee 可为 null（未指派），
 * 指派时必须是已存在的 agent id —— 由外键兜底（openDatabase 已开 PRAGMA foreign_keys），
 * 违反时 SQLite 直接抛约束错误，不静默落库。
 */
export function insertTask(db, task) {
  if (!task || typeof task !== 'object') throw new TypeError('task 必须是对象');
  const { title, description, assignee, status } = task;
  if (typeof title !== 'string' || title.trim() === '') {
    throw new TypeError('task.title 必须是非空字符串');
  }
  if (status !== undefined && !TASK_STATUSES.includes(status)) {
    throw new RangeError(`task.status 必须是 ${TASK_STATUSES.join(' / ')} 之一，收到：${status}`);
  }
  if (description !== undefined && typeof description !== 'string') {
    throw new TypeError('task.description 必须是字符串');
  }
  if (assignee !== undefined && assignee !== null && typeof assignee !== 'string') {
    throw new TypeError('task.assignee 必须是字符串（agent id）或 null');
  }

  const row = {
    id: typeof task.id === 'string' && task.id ? task.id : randomUUID(),
    title: title.trim(),
    description: description ?? '',
    assignee: assignee ?? null,
    status: status ?? 'queued',
    claimed_at: null,
    created_at: Date.now(),
    result_path: null,
  };
  db.run(
    'INSERT INTO tasks (id, title, description, assignee, status, claimed_at, created_at, result_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [row.id, row.title, row.description, row.assignee, row.status, row.claimed_at, row.created_at, row.result_path],
  );
  return row;
}

/** 按 id 查任务，查无返回 null。 */
export function getTaskById(db, id) {
  return db.get('SELECT * FROM tasks WHERE id = ?', [id]) ?? null;
}

/** 任务列表，可按状态筛（不传返回全部）；created_at 倒序（新任务在前），同毫秒按 rowid 决胜。 */
export function listTasks(db, { status } = {}) {
  if (status !== undefined) {
    if (!TASK_STATUSES.includes(status)) {
      throw new RangeError(`status 必须是 ${TASK_STATUSES.join(' / ')} 之一，收到：${status}`);
    }
    return db.all('SELECT * FROM tasks WHERE status = ? ORDER BY created_at DESC, rowid DESC', [status]);
  }
  return db.all('SELECT * FROM tasks ORDER BY created_at DESC, rowid DESC');
}

/**
 * 原子领取任务 —— 全项目并发正确性的关键点。
 *
 * 绝不"先 SELECT 看 status 再 UPDATE"：两步之间有竞态窗口，并发下会双双成功。
 * 而是把"判断 + 占有"压进一条 UPDATE：
 *   UPDATE tasks SET status='claimed', assignee=?, claimed_at=? WHERE id=? AND status='queued'
 * WHERE 同时卡 id 与 queued，SQLite 的写互斥保证同一行只有一个调用能命中（changes=1），
 * 抢输的命中 0 行（changes=0）。哪怕将来换成真并发的驱动，这个语义也不变。
 *
 * 已实验确认 node-sqlite3-wasm 的 db.run() 返回 { changes, lastInsertRowid }，
 * changes 即受影响行数，据此判定输赢 —— 不靠猜。
 *
 * 返回：抢到 { ok: true, task }；没抢到（已被人领走/任务不存在）{ ok: false, reason: 'not_queued' }。
 */
export function claimTask(db, taskId, agentId) {
  if (typeof agentId !== 'string' || agentId === '') {
    throw new TypeError('claimTask 的 agentId 必须是非空字符串');
  }
  const { changes } = db.run(
    "UPDATE tasks SET status = 'claimed', assignee = ?, claimed_at = ? WHERE id = ? AND status = 'queued'",
    [agentId, Date.now(), taskId],
  );
  if (changes !== 1) return { ok: false, reason: 'not_queued' };
  return { ok: true, task: getTaskById(db, taskId) };
}

/**
 * 更新任务状态；extras 可带 result_path（如 done 时附产物路径）。
 * 返回更新后的完整行；任务不存在时不写入、返回 null。
 */
export function updateTaskStatus(db, taskId, status, extras = {}) {
  if (!TASK_STATUSES.includes(status)) {
    throw new RangeError(`status 必须是 ${TASK_STATUSES.join(' / ')} 之一，收到：${status}`);
  }
  const { result_path } = extras ?? {};
  if (result_path !== undefined && typeof result_path !== 'string') {
    throw new TypeError('extras.result_path 必须是字符串');
  }
  if (result_path !== undefined) {
    db.run('UPDATE tasks SET status = ?, result_path = ? WHERE id = ?', [status, result_path, taskId]);
  } else {
    db.run('UPDATE tasks SET status = ? WHERE id = ?', [status, taskId]);
  }
  return getTaskById(db, taskId); // 命中 0 行自然返回 null
}

// ---------------------------------------------------------------------------
// 事件（events）
// ---------------------------------------------------------------------------

/**
 * limit 归一（事件查询共用）：undefined → def；非整数 / 小于 1 → def（回落默认）；
 * 超过 max 静默截到 max（任务书口径：不报错）。上限 1000 对两个查询统一生效。
 */
function normalizeLimit(limit, def, max = 1000) {
  if (limit === undefined) return def;
  if (typeof limit !== 'number' || !Number.isInteger(limit) || limit < 1) return def;
  return Math.min(limit, max);
}

/**
 * 写入一条事件，返回落库后的完整行（读回真实行，payload 是 JSON 字符串，API 层负责还原）。
 * type 必须在 EVENT_TYPES 里，否则 RangeError；payload 是任意对象（数组也收，JSON 往返无损），
 * 默认 {}；task_id / agent_id 可为 null（有些事件不绑定任务或 Agent，如系统级 note）。
 * 引用存在性由外键兜底，但 API 层会先验存在再落库，给出更准的 404。
 */
export function insertEvent(db, event) {
  if (!event || typeof event !== 'object') throw new TypeError('event 必须是对象');
  const { task_id, agent_id, type, payload } = event;
  if (!EVENT_TYPES.includes(type)) {
    throw new RangeError(`event.type 必须是 ${EVENT_TYPES.join(' / ')} 之一，收到：${type}`);
  }
  if (payload !== undefined && (typeof payload !== 'object' || payload === null)) {
    throw new TypeError('event.payload 必须是对象');
  }
  const { lastInsertRowid } = db.run(
    'INSERT INTO events (task_id, agent_id, type, payload, created_at) VALUES (?, ?, ?, ?, ?)',
    [task_id ?? null, agent_id ?? null, type, JSON.stringify(payload ?? {}), Date.now()],
  );
  return getEventById(db, lastInsertRowid);
}

/** 按主键查事件，查无返回 null。 */
export function getEventById(db, id) {
  return db.get('SELECT * FROM events WHERE id = ?', [id]) ?? null;
}

/**
 * 某任务的事件流，created_at 升序（事件流要看时间顺序）。
 * 同毫秒按 rowid 决胜，保持插入序（AUTOINCREMENT 单调递增，见 schema.md）。
 * limit 默认 100、最大 1000（超过静默截断）。
 */
export function listEventsByTask(db, taskId, { limit } = {}) {
  const n = normalizeLimit(limit, 100);
  return db.all('SELECT * FROM events WHERE task_id = ? ORDER BY created_at, rowid LIMIT ?', [taskId, n]);
}

/** 全量最近事件，created_at 倒序（新的在前），同毫秒按 rowid 倒序决胜。limit 默认 50、最大 1000。 */
export function listRecentEvents(db, { limit } = {}) {
  const n = normalizeLimit(limit, 50);
  return db.all('SELECT * FROM events ORDER BY created_at DESC, rowid DESC LIMIT ?', [n]);
}
